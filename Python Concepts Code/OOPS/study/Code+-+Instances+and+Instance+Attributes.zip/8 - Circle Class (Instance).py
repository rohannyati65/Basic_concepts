"""
Course: Python OOP - Object Oriented Programming for Beginners
By: Estefania Cassingena Navone
"""

class Circle:

    def __init__(self, radius):
        self.radius = radius


my_circle = Circle(5)

print(my_circle)
