"""
Course: Python OOP - Object Oriented Programming for Beginners
By: Estefania Cassingena Navone
"""

class Rectangle:

    def __init__(self, length, width):
        self.length = length
        self.width = width


my_rectangle = Rectangle(3, 6)

print(my_rectangle)
