"""
Course: Python OOP - Object Oriented Programming for Beginners
By: Estefania Cassingena Navone
"""

class House:
    
    def __init__(self, price):
        self.price = price
