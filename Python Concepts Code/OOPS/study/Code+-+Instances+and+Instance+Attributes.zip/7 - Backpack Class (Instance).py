"""
Course: Python OOP - Object Oriented Programming for Beginners
By: Estefania Cassingena Navone
"""

class Backpack:
    
    def __init__(self):
        self.items = []


my_backpack = Backpack()

print(my_backpack)
